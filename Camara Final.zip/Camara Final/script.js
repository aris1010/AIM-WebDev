// Function to update time
function updateTime() {
    const now = new Date();
    const timeElement = document.getElementById('time');
    timeElement.textContent = 'Current Time: ' + now.toLocaleTimeString();
}

// Function to update date
function updateDate() {
    const now = new Date();
    const dateElement = document.getElementById('date');
    dateElement.textContent = 'Today\'s Date: ' + now.toDateString();
}



// Update time and date initially
updateTime();
updateDate();

// Add event listener to update mouse position
document.addEventListener('mousemove', updatePosition);